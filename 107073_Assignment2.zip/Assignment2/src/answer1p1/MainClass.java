package answer1p1;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.chainsaw.Main;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;



public class MainClass {
	Session session;
	Transaction t;
	List<String> list=new ArrayList<>();
		public MainClass() {
			// load cdg file
			Configuration cfg = new AnnotationConfiguration();
			// Session factory
			SessionFactory factory = cfg.configure().buildSessionFactory();
			// session
			session = factory.openSession();
			// transaction
			t = session.beginTransaction();
			// business operation
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MainClass main=new MainClass();
		main.addData();
		
	}

	public void addData()
	{
		list.add("It was bad");
		Event event=new Event("Infogain Fest", list);
		session.save(event);
		t.commit();
		session.close();
		
	}
}
