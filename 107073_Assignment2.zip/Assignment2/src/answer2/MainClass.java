package answer2;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import answer1p2.Event1;

public class MainClass {
Scanner sc=new Scanner(System.in);
List<Product> list=new ArrayList<>();
	public static void main(String[] args) throws ParseException {
	
		MainClass main=new MainClass();
		
		while (true) {
			System.out.println("enter choice:");
			System.out.println("1 to add");
			System.out.println("2 to descending order on the basis of price");
			System.out.println("3 to product whose price is greater than avg price");
			System.out.println("4 to increment");
			System.out.println("5 to delete whose exp_date has reached");
			System.out.println("6 to display all the data");
			System.out.println("0 to exit");
			int ch = Integer.parseInt(main.sc.nextLine());
			switch (ch) {
			case 1:
				main.addDetails();
				break;
			case 2:
				main.displayDetialsInDescOrder();
				break;
			case 3:
				main.displayPriceGreaterThanAvg();
				break;
				
			case 4:
				main.increment();
				break;
			case 5:
				main.expData();
				break;
			case 6:
				main.displayAllData();
				break;
			case 0:
				System.exit(0);

			default:
				System.out.println("Wrong choice");
				break;
			}// switch end

		} // while end
		
	}
	
	public void addDetails() throws ParseException
	{
		
		System.out.println("How many product u want to insert");
		int count=Integer.parseInt(sc.nextLine());
		for (int i = 0; i < count; i++) {
			
			System.out.println("enter name");
			String productName=sc.nextLine();
		
			System.out.println("manuf date in yyyy-MM-dd");
			String manufDate=sc.nextLine();
			
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			
			Date date1=sdf.parse(manufDate);
			java.sql.Date manufDate1= new java.sql.Date(date1.getTime());
			
			System.out.println("enter exp date in yyyy-MM-dd");
			String expDate=sc.nextLine();
			
			Date date=sdf.parse(expDate);
			java.sql.Date expDate1= new java.sql.Date(date.getTime());
			
			System.out.println("enter price");
			float price=Float.parseFloat(sc.nextLine());
		
			Product product=new Product(productName, manufDate1, expDate1, price);
			list.add(product);
			
		}
		
		insertDetails(list);
		
	}
	
	public void insertDetails(List<Product> list)
	{
		Session session = HibernateUitl.util();
		Transaction t = session.beginTransaction();	
		for (Product product : list) {
			session.save(product);
		}
		t.commit();
	}
	
	public void displayDetialsInDescOrder()
	{
		Session session=HibernateUitl.util();
		Transaction t=session.beginTransaction();
		Criteria criteria=session.createCriteria(Product.class);
		ArrayList<Product> product=(ArrayList<Product>) criteria.addOrder(Order.desc("price")).list();
		for (Product product2 : product) {
			System.out.println(product2);
		}
		t.commit();
	}
	
	public float average()
	{
		Session session=HibernateUitl.util();
		Transaction t=session.beginTransaction();
		List<Product> p=session.createQuery("from Product").list();

		float avg=0;
	for (Product product : p) {
		avg=avg+product.getPrice();
	}
	
	avg=avg/p.size();
	return avg;
	}
	public void displayPriceGreaterThanAvg()
	{
		Session session=HibernateUitl.util();
		Transaction t=session.beginTransaction();
		Criteria criteria=session.createCriteria(Product.class);
		List<Product> p=criteria.add(Restrictions.gt("price", average())).list();
	for (Product product : p) {
		System.out.println(product);
		
	}
	t.commit();
	}
	
	public void expData()
	{
		Date date=new Date();
		Session session=HibernateUitl.util();
		Transaction t=session.beginTransaction();
		Criteria criteria=session.createCriteria(Product.class);
		List<Product> p=criteria.add(Restrictions.le("expDate", date)).list();
		for (Product product : p) {
			System.out.println(product+"--->deleted");
			session.delete(product);
		}
		t.commit();
		
	}
	
	public void increment()
	{
		Session session=HibernateUitl.util();
		Transaction t=session.beginTransaction();
		
		
				
				org.hibernate.Query q=session.createQuery("update Product set price=(price+(price*0.05)) where (price>'1000')");
				int a=q.executeUpdate();
				System.out.println("____________Update Done_______"+a);
			
		
				org.hibernate.Query q1=session.createQuery("update Product set price=(price+(price*0.05)) where (price<'1000')");
				int b=q.executeUpdate();
				System.out.println("____________Update Done_______"+b);
			
			
		
		t.commit();
	
	}
	
	
	
	public void displayAllData()
	{
		Session session=HibernateUitl.util();
		Transaction t=session.beginTransaction();
		List<Product> p=session.createQuery("from Product").list();
		for (Product product : p) {
			System.out.println(product);
		}
	}
	
	
}
