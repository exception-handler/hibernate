package answer3;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;



@Entity
public class Reply {

	@Id
	private int replyId;
	private String replyName;
	private String sendBy;
	public int getReplyId() {
		return replyId;
	}
	public void setReplyId(int replyId) {
		this.replyId = replyId;
	}
	public String getReplyName() {
		return replyName;
	}
	public void setReplyName(String replyName) {
		this.replyName = replyName;
	}
	public String getSendBy() {
		return sendBy;
	}
	public void setSendBy(String sendBy) {
		this.sendBy = sendBy;
	}
	@Override
	public String toString() {
		return "Reply [replyId=" + replyId + ", replyName=" + replyName + ", sendBy=" + sendBy + "]";
	}
	public Reply(int replyId, String replyName, String sendBy) {
		super();
		this.replyId = replyId;
		this.replyName = replyName;
		this.sendBy = sendBy;
	}
	public Reply() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
