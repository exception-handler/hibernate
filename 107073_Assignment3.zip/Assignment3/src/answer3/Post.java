package answer3;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Post {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int postId;
	private String postName;
	private String reply;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Reply replyDetails;

	public int getPostId() {
		return postId;
	}

	public void setPostId(int postId) {
		this.postId = postId;
	}

	public String getPostName() {
		return postName;
	}

	public void setPostName(String postName) {
		this.postName = postName;
	}

	public String getReply() {
		return reply;
	}

	public void setReply(String reply) {
		this.reply = reply;
	}

	public Reply getReplyDetails() {
		return replyDetails;
	}

	public void setReplyDetails(Reply replyDetails) {
		this.replyDetails = replyDetails;
	}

	@Override
	public String toString() {
		return "Post [postId=" + postId + ", postName=" + postName + ", reply=" + reply + ", replyDetails="
				+ replyDetails + "]";
	}

	public Post(String postName, String reply, Reply replyDetails) {
		super();
		this.postName = postName;
		this.reply = reply;
		this.replyDetails = replyDetails;
	}

	public Post() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
