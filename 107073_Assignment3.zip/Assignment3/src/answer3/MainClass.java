package answer3;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;


public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			// load cdg file
				Configuration cfg = new AnnotationConfiguration();
				// Session factory
				SessionFactory factory = cfg.configure().buildSessionFactory();
				// session
				Session  session= factory.openSession();
				// transaction

				Transaction t=session.beginTransaction();
				
				Post post=new Post("postName", "reply",new Reply(101, "replyName", "sendBy"));
				session.save(post);
				t.commit();
				session.close();
	}

}
