package answer3Bidirectional;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Post1 {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int postId;
	private String postName;
	private String reply;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Reply1 replyDetails;

	public int getPostId() {
		return postId;
	}

	public void setPostId(int postId) {
		this.postId = postId;
	}

	public String getPostName() {
		return postName;
	}

	public void setPostName(String postName) {
		this.postName = postName;
	}

	public String getReply() {
		return reply;
	}

	public void setReply(String reply) {
		this.reply = reply;
	}

	public Reply1 getReplyDetails() {
		return replyDetails;
	}

	public void setReplyDetails(Reply1 replyDetails) {
		this.replyDetails = replyDetails;
	}

	@Override
	public String toString() {
		return "Post [postId=" + postId + ", postName=" + postName + ", reply=" + reply + ", replyDetails="
				+ replyDetails + "]";
	}

	public Post1(String postName, String reply, Reply1 replyDetails) {
		super();
		this.postName = postName;
		this.reply = reply;
		this.replyDetails = replyDetails;
	}

	public Post1() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
