package answer3Bidirectional;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import answer3.Post;
import answer3.Reply;


public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			// load cdg file
				Configuration cfg = new AnnotationConfiguration();
				// Session factory
				SessionFactory factory = cfg.configure().buildSessionFactory();
				// session
				Session  session= factory.openSession();
				// transaction

				Transaction t=session.beginTransaction();	
				/*
				Post1 post1=new Post1("a", "b", new Reply1(10, "roh", "me"));
				session.save(post1);
				t.commit();
				*/Reply1 reply=(Reply1)session.get(Reply1.class, 10);
				System.out.println(reply.getPost().getPostId());
				
				t.commit();
	}

}
