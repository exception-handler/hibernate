package answer3Bidirectional;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;



@Entity
public class Reply1 {

	@Id
	private int replyId;
	private String replyName;
	private String sendBy;
	@OneToOne(mappedBy="replyDetails",cascade=CascadeType.ALL)            //bidirectional
	 //same as in Person
	private Post1 post;
	public int getReplyId() {
		return replyId;
	}
	public void setReplyId(int replyId) {
		this.replyId = replyId;
	}
	public String getReplyName() {
		return replyName;
	}
	public void setReplyName(String replyName) {
		this.replyName = replyName;
	}
	public String getSendBy() {
		return sendBy;
	}
	public void setSendBy(String sendBy) {
		this.sendBy = sendBy;
	}
	public Post1 getPost() {
		return post;
	}
	public void setPost(Post1 post) {
		this.post = post;
	}
	@Override
	public String toString() {
		return "Reply [replyId=" + replyId + ", replyName=" + replyName + ", sendBy=" + sendBy + ", post=" + post + "]";
	}
	public Reply1(int replyId, String replyName, String sendBy) {
		super();
		this.replyId = replyId;
		this.replyName = replyName;
		this.sendBy = sendBy;
		//this.post = post;
	}
	public Reply1() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
