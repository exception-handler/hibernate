package answer1;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy=InheritanceType.JOINED)
public class Payment {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int paymentId;
	private String custName;
	private int custMobile;
	private String custAddress;
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public int getCustMobile() {
		return custMobile;
	}
	public void setCustMobile(int custMobile) {
		this.custMobile = custMobile;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	@Override
	public String toString() {
		return "Payment [paymentId=" + paymentId + ", custName=" + custName + ", custMobile=" + custMobile
				+ ", custAddress=" + custAddress + "]";
	}
	public Payment(String custName, int custMobile, String custAddress) {
		super();
		this.custName = custName;
		this.custMobile = custMobile;
		this.custAddress = custAddress;
	}
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
