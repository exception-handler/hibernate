package answer1;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class MainClass {
	Session session;
	Transaction t;

	public MainClass() {
		// load cdg file
		Configuration cfg = new AnnotationConfiguration();
		// Session factory
		SessionFactory factory = cfg.configure().buildSessionFactory();
		// session
		session = factory.openSession();
		// transaction
		

	}

	public static void main(String[] args) {

		MainClass m = new MainClass();
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("enter choice:");
			System.out.println("1 to add payment");
			System.out.println("2 to update payment");
			System.out.println("3 to delete payment");
			System.out.println("4 to search payment");
			System.out.println("0 to exit");
			int ch = Integer.parseInt(sc.nextLine());
			switch (ch) {
			case 1:
				m.addPayment();
				break;
			case 2:

				break;
			case 3:

				break;
			case 4:

				break;
			case 0:
				System.exit(0);

			default:
				System.out.println("Wrong choice");
				break;
			}// switch end

		} // while end

	}// main end

	public void addPayment()
	
		{	
		t=session.beginTransaction();
		Scanner sc=new Scanner(System.in);
			System.out.println("enter payment details:");
			System.out.println("enter custName:");
			String custName=sc.nextLine();
			System.out.println("enter custMobile");
			int custMobile=Integer.parseInt(sc.nextLine());
			System.out.println("enter custAddress");
			String custAddress=sc.nextLine();
			
			
			System.out.println("enter type of payment cash or creditcard");
			String choice=sc.nextLine();
			
			if(choice.equalsIgnoreCase("cash"))
			{
				
			System.out.println("Enter total amount");
			int totalAmount=Integer.parseInt(sc.nextLine());
			System.out.println("enter paid amount");
			int paidAmount=Integer.parseInt(sc.nextLine());
			Cash cash=new Cash(custName, custMobile, custAddress, totalAmount, paidAmount);
			session.save(cash);
			
			
			}
			
			else if(choice.equalsIgnoreCase("creditcard"))
			{
				
			System.out.println("Enter credit card number");
			int cc=Integer.parseInt(sc.nextLine());
			System.out.println("enter bank");
			String bank=sc.nextLine();
			System.out.println("enter date of exp in yyyy-mm-dd");
			String date=sc.nextLine();
			CreditCard creditcard=new CreditCard(custName, custMobile, custAddress, cc, bank, date);
			session.save(creditcard);
			
			}
			
			t.commit();
			}// addpayment
																																																																																																																																																																			// end

}
