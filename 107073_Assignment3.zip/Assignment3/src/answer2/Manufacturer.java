package answer2;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Manufacturer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int manufInt;
	private String manufName;

	@Embedded
	private Item item;

	public int getManufInt() {
		return manufInt;
	}

	public void setManufInt(int manufInt) {
		this.manufInt = manufInt;
	}

	public String getManufName() {
		return manufName;
	}

	public void setManufName(String manufName) {
		this.manufName = manufName;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	@Override
	public String toString() {
		return "Manufacturer [manufInt=" + manufInt + ", manufName=" + manufName + ", item=" + item + "]";
	}

	public Manufacturer(String manufName, Item item) {
		super();
		this.manufName = manufName;
		this.item = item;
	}

	public Manufacturer() {
		super();
		// TODO Auto-generated constructor stub
	}

}
