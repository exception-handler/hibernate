package answer2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class MainClass {
	  
	public static void main(String[] args) {
		
		// load cdg file
		Configuration cfg = new AnnotationConfiguration();
		// Session factory
		SessionFactory factory = cfg.configure().buildSessionFactory();
		// session
		Session  session= factory.openSession();
		// transaction

		Transaction t=session.beginTransaction();
		Manufacturer manu=new Manufacturer("Rohit", new Item(101, "name"));
		
		session.save(manu);
		t.commit();
		session.close();
	}
}
